﻿# Examples of  Richard Barry´s book w/freeRTOS & sAPI.
#
# https://www.freertos.org/Documentation/RTOS_book.html
#
#  EXAMPLE017: Using a counting semaphore to synchronize a task with an interrupt
#