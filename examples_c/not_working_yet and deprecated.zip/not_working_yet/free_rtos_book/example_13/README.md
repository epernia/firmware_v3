﻿# Examples of  Richard Barry´s book w/freeRTOS & sAPI.
#
# https://www.freertos.org/Documentation/RTOS_book.html
#
#  EXAMPLE013: Creating one-shot and auto-reload timers
#