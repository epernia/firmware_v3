﻿# Examples of  Richard Barry´s book w/freeRTOS & sAPI.
#
# https://www.freertos.org/Documentation/RTOS_book.html
#
#  EXAMPLE021: Re-writing vPrintString() to use a gatekeeper task
#