#ifndef _PROGRAMA1_H_
#define _PROGRAMA1_H_

#ifdef __cplusplus
extern "C" {
#endif



#ifdef __cplusplus
}
#endif

#endif /* _PROGRAMA1_H_ */
