Este ejemplo hace un bridge entre un puerto Serie virtual en el USB OTG y el
puerto serie del USB DEBUG (UART2) de la EDU-CIAA. Se deben configurar ambos
puertos (por ejemplo, /dev/ttYUSB1 y /dev/ttyACM0) a 115200 baudios.
