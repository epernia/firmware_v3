﻿# Examples of  Richard Barry´s book w/freeRTOS & sAPI.
#
# https://www.freertos.org/Documentation/RTOS_book.html
#
#  EXAMPLE019: Sending and receiving on a queue from within an interrupt
#