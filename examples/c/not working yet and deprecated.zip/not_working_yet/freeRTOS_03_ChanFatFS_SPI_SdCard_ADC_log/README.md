# ADC log con timestamp del RTC en la SD (conectada por SPI) con FreeRTOS

Este programa loguea el ADC en un archivo en la tarjeta SD hasta que se mantenga presionada TEC1 o pase un minuto.

Conectar a la UART_USB, 8N1 a 115200 baudios.
