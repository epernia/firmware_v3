//        I2C_BB_PG_DEF.C  - FUNCTIONS  DEFINITION 
 //****************************************************************************
 // File Name    : i2c_bb_pg_def.c 
 // Dependencies : i2c_bb_pg_dec.h = functions declaration  
 //                REG952.h     = SFRs definitions offered by "Keil" 
 //                STARTUP950   = start-up code for LPC952 ( "Keil" )  
 // Processor    : P89LPC952  
 // Hardware     : MicroChip's I2C EEPROM = 24xx512 on MCB950 EVB . 
 // I.D.E.       : uVision3 - Keil 
 // Company      : MicroChip Technology , Inc. 
 //...........................................................................
 //                SOFTWARE  LICENSE AGREEMENT 
 //...........................................................................
 // "Microchip Technology Inc. (�Microchip�) licenses this software to you 
 // solely for use with Microchip Serial EEPROM products. 
 // The software is owned by Microchip and/or its licensors,and is protected 
 // under applicable copyright laws.  All rights reserved.
 // SOFTWARE IS PROVIDED �AS IS.�  MICROCHIP AND ITS LICENSOR EXPRESSLY 
 // DISCLAIM ANY WARRANTY OF ANY KIND, WHETHER EXPRESS OR IMPLIED, INCLUDING 
 // BUT NOT LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY, FITNESS 
 // FOR A PARTICULAR PURPOSE,OR NON-INFRINGEMENT. IN NO EVENT SHALL MICROCHIP 
 // AND ITS LICENSORS BE LIABLE FOR ANY INCIDENTAL, SPECIAL, INDIRECT OR 
 // CONSEQUENTIAL DAMAGES, LOST PROFITS OR LOST DATA, HARM TO YOUR EQUIPMENT, 
 // COST OF PROCUREMENT OF SUBSTITUTE GOODS, TECHNOLOGY OR SERVICES, ANY 
 // CLAIMS BY THIRD PARTIES (INCLUDING BUT NOT LIMITED TO ANY DEFENSE 
 // THEREOF),ANY CLAIMS FOR INDEMNITY OR CONTRIBUTION, OR OTHER SIMILAR COSTS."
 //***************************************************************************
 // History      :  V1.0 - Initial Release 
 //...........................................................................
 // File Description : This is the file declaring all the necesary functions
 //                    for the application note ANxxxx . 
 //                    Functions are declared in "i2c_bb_dec.h" and defined in
 // the below file . As described , there are 3 types of  functions : 
 // initialization , i2c_access , auxiliary . Moreover , the function defines 
 // the public variables ( byte & bit ) and the slave_address constants :
 // for write and read .                     
 //.............................................................................
    #include "REG952.h"
    #include "i2c_bb_pg_dec.h" 
     sfr S1CONX = 0xB6  ;     // correct declaration of S1CON     
//.............................................................................
//                         GLOBAL CONSTANTS 
//............................................................................
     #define  DEV_ADR_WR  0xa0           // slave address + write_bit 
     #define  DEV_ADR_RD  0xa1           // slave address +  read_bit 
//............................................................................ 
//                  GLOBAL  VARIABLES
//............................................................................      
      unsigned char bdata eep_buf         ;      //   eeprom's data buffer  
            sbit shift7 = eep_buf^7       ;      //   bit7 of  data buffer
            sbit shift0 = eep_buf^0       ;      //   bit0 of  data buffer 
//...........................................................................
//           INITIALIZATION FUNCTIONS  
//...........................................................................
         void  ini_intr(void)  // interrupts'   init                       
    { // IEN0 = 0x00 ; 
      // IEN1 = 0x00 ; 
      // IEN2 = 0x00 ;         // disable all interrupts                        
                           }   //  reset value = 00 , disable intr

       void  ini_wdt(void)     // W.D.T.'s init - WDT disabled in UCFG1 
    {  WDCON = 0xe0          ; // WDCON = PRE210-xx-WDRUN-WDTOF-WDCLK  
       WDL   = 0xff          ; // roll-over at maximum 
       WFEED1 = 0xa5         ; // stop WDT even it's underflow reset is dis 
       WFEED2 = 0x5a         ; // feed sequence after WDCON write-intr dis
                           } 

       void  ini_osc(void)     // oscillator's init-TRIM=RCCLK-ENCLK-TRIM5,0 
    {  TRIM |= 0xc0         ;  // RCCLK=ENCLK=1 (trim value remains the same)                     
                               // enable CCLK:2 on XTAL2 = P3.0 
                           } 
    
       void  ini_gpio(void)    // GPIO's  init
    {  P0M1 = 0xff          ;  // P0 = analog apps , all bits = inputs 
       P0M2 = 0x00          ;   
       P1M1 = 0xfe          ;  // P0=I2C->P1.3=SDA=open dr,P1.2=SCL=open dr   
       P1M2 = 0x0d          ;  // COM0->P1.1=RXD0=inp , P1.0=TXD0=push pull 
       P3M1 = 0x02          ;  // P3.1 = XTAL1 = inp 
       P3M2 = 0x01          ;  // P3.0 = CLKOUT= out push pull 
       P4M1 = 0x0a          ;  // P4.3=RXD1=inp , P4.2=TXD1=push pull , 
       P4M2 = 0x05          ;  // P4.1=TRIG=inp , P4.0=nCS =push pull . 
       P5M1 = 0x00          ;  // all P5's bits = bi - directional 
       P5M2 = 0x00          ;  // 
       P5   = 0x00          ;  // clear all LEDs 
                         } 

       void  ini_i2c(void)     // I2C bit-bang init 
    {  SDA = 1   ; SCL = 1  ;  // SDA = SCL = 1 , pre-start condition 
                         }                            

       void  ini_com1(void)    // UART1's      init
    {  
//     S1CON    = 0x52      ;  //SM01=01=8bUART-REN=1-TB8/RB8=00,TI=1,RI=0
       S1CONX   = 0x52      ;   
       BRG0_1   = 0xf0      ;  // BAUD=256*BRG1+BRG0+16 
       BRG1_1   = 0x02      ;  // 7.373Mhz : 9600 = 768 = 2*256+240+16 
       BRGCON_1 = 0x03      ;  // 9600 baud + 1b_start + 8b_date + 1b_stop  
                         }      

       void  ini_tim(void)     // Timers'  init
    {  TMOD = 0x22          ;  // T0,1 = MODE2 (8b auto-reload)  
                               // GATE0,1=0(delay timer_0 will start at TR0) 
                         }      
//.............................................................................  
//             I2C  ACCESS FUNCTIONS  DEFINITIONS 
//*****************************************************************************
             void i2c_start(void) 
           {   SDA = 1 ; SCL = 1 ;         // initial state of the I2C bus 
               dly_usec(7) ; SDA = 0 ;     // SCL=1 , SDA=0 after 7 usecs 
               dly_usec(5) ; SCL = 0 ;     // SCL=0 , SDA=0 after other 5 usecs                       
                                        } 
//.............................................................................
             void i2c_stop(void) 
           {  SDA = 0 ;                    // SDA=0,SCL=0, initial state of I2C
              dly_usec(2) ; SCL = 1 ;      // SDA=0,SCL=1, after 2 usecs 
              dly_usec(6) ; SDA = 1 ;      // SDA=1,SCL=1, after other 5 usecs                     
                                     }   
//.............................................................................
             void nack_mcu(void) 
           { SDA = 1 ; dly_usec(3) ;     // SDA=1,SCL=0 for 3 usecs 
             SCL = 1 ; dly_usec(6) ;     // SDA=1,SCL=1 for 6 usecs ; +pulse SCL  
             SCL = 0 ; dly_usec(2) ;     // SDA=1,SCL=0,SCL stabilization 2us                     
                                      }
//............................................................................
             void  ack_mcu(void)
           { SDA = 0 ; dly_usec(3) ;     // SDA=0,SCL=0 for 3 usec 
             SCL = 1 ; dly_usec(6) ;     // +pulse SCL  for 6 usec
             SCL = 0 ; dly_usec(2) ;     // 2 usec stabilization for SCL 
             SDA = 1 ; dly_usec(2) ;     // prepare SDA for reception 
                                      }  
//............................................................................
             void i2c_wr(void)           // write an 8b streaming 
      { unsigned char bit_count = 0 ;    // bit counter for the 8b streaming 
        while(bit_count<8) 
        { dly_usec(3) ; SDA=shift7  ;    // SDA = bit_n of eeprom's data buffer 
          dly_usec(2) ; SCL=1       ;    // pulse high SCL 
          dly_usec(5) ; SCL=0       ;    // for 5 microseconds 
          eep_buf=eep_buf<<1        ;    // shift left 1bit the eep's data buf 
          bit_count++ ; dly_usec(2) ; }  // increment bit counter(repeat for 8b)
          SDA=1 ; P1M2=0x05         ;    // rise-up SDA and program it as input    
          dly_usec(3)               ;    // to read the ACK from the memory 
          SCL=1 ; dly_usec(5)       ;    // pulse high SCL for 5 useconds 
          SCL=0 ; P1M2=0x0d         ;    // program again SDA as open-drain out                          
                                        } 
//............................................................................
         unsigned char i2c_rd(void)      // read an 8b streaming 
      { unsigned char bit_count = 0 ;    // bit counter the 8b streaming 
        SDA=1 ; P1M2=0x05           ;    // prepare SDA as input (=1) 
        while(bit_count<8)   
       { eep_buf=eep_buf<<1         ;    // shift left 1b eeprom data buffer
         dly_usec(4) ; SCL=1        ;    // rise-up SCL  
         shift0=SDA ; dly_usec(4)   ;    // read bit_n from eeprom 
         SCL=0 ; dly_usec(2)        ;    // pulse SCL   
         bit_count++ ; dly_usec(2)  ; }  // increment bit counter(repeat for 8b) 
         P1M2=0x0d ; return eep_buf ;    // SDA open drain(return data buf) 
                                        } 
//...........................................................................
      void i2c_rndwr(unsigned int eep_adr, unsigned char eep_data) 
      {  i2c_start()                ;    // START command 
         eep_buf = DEV_ADR_WR       ; 
         i2c_wr()                   ;    // write first slave adr + write_bit 
         eep_buf = eep_adr>>8       ; 
         i2c_wr()                   ;    // write the high_byte of the adr 
         eep_buf = eep_adr&0xff     ;      
         i2c_wr()                   ;    // write the  low_byte of the adr
         eep_buf = eep_data         ; 
         i2c_wr()                   ;    // write the data_character 
         i2c_stop()                 ;    // finally , STOP command 
         dly5ms()                   ;    // write cycle time after each byte  
                                        } 
//............................................................................
         void i2c_rndrd(unsigned int eep_adr,unsigned char *dst) 
      {  i2c_start()                ;  // START command 
         eep_buf = DEV_ADR_WR       ;      
         i2c_wr()                   ;  // write slave address + write_bit 
         eep_buf = eep_adr>>8       ; 
         i2c_wr()                   ;  // write the high_byte of the adr 
         eep_buf = eep_adr&0xff     ;      
         i2c_wr()                   ;  // write the  low_byte of the adr 
         i2c_start()                ;  // REPEATED START condition 
         eep_buf = DEV_ADR_RD       ;       
         i2c_wr()                   ;  // change the direction of the trsf 
         *dst = i2c_rd()            ;  // store the result in "dst"(<-eep_buf)
         nack_mcu()                 ;  // send a NACK from MCU to the memory 
         i2c_stop()                 ;  // finally , STOP command              
                                        } 
//............................................................................
  void i2c_pgwr(unsigned char *source,unsigned int eep_adr,unsigned char lofsstr)
  { 
   unsigned char k = 0              ;  // auxiliary counter 
   i2c_start()                      ;  // START command 
   eep_buf = DEV_ADR_WR             ; 
   i2c_wr()                         ;  // write SLAVE ADDRESS + wr_bit 
   eep_buf = eep_adr>>8             ;
// eep_buf = (eep_adr>>8)&0xff      ;  
   i2c_wr()                         ;  // write high address 
   eep_buf = eep_adr&0xff           ; 
   i2c_wr()                         ;  // write low address 
   while(k<lofsstr)
   { eep_buf = *source              ;  // load buffer from char string 
 //  eep_buf = source[k]            ; 
 //  eep_buf = *(source+k)          ; 
     i2c_wr()                       ;  // stream data in the memory 
     source++                       ;  // increment pointer 
	      k++                       ;  // increment counter 
                   }				   // do until end 
	 i2c_stop()                     ;  // STOP command 
	 dly5ms()                       ;  // final write cycle time 
                               }          
//............................................................................
  void i2c_pgrd(unsigned char *dest,unsigned int eep_adr,unsigned char lofdstr)
      {  unsigned char k = 0        ;  // auxiliary counter 
         i2c_start()                ;  // START command 
         eep_buf = DEV_ADR_WR       ;      
         i2c_wr()                   ;  // write slave address + write_bit 
         eep_buf = eep_adr>>8       ; 
         i2c_wr()                   ;  // write the high_byte of the adr 
         eep_buf = eep_adr&0xff     ;      
         i2c_wr()                   ;  // write the  low_byte of the adr 
         i2c_start()                ;  // REPEATED START condition 
         eep_buf = DEV_ADR_RD       ;       
         i2c_wr()                   ;  // change the direction of the trsf
         if(lofdstr==1)   ;            // if single byte string 
//         {;}                         // do nothing , the byte will be read
                                       // & the NACK will be sent at the end
         else 
	   { while(k<lofdstr-1)            // if length of the string > 1 
                                       // do for the first (lofdstr-1) bytes
       { *dest = i2c_rd()           ;  // read byte 
           ack_mcu()                ;  // send ACK, requesting more bytes 
           dest++ ; k++ ;     }     }  // increment pointer & counter 
           *dest = i2c_rd()         ;  // read the last byte 
           nack_mcu()               ;  // send the final NACK (for the last byte)    
           i2c_stop()         ;     }  // STOP transfer            

//****************************************************************************
//               AUXILIARY  FUNCTIONS  DEFINITIONS 
//****************************************************************************
   void dly_usec(unsigned char num_usec) // delay in micro-seconds
// Since 8051_Timers in mode2 work on 8 bits,the argument of the function
// may not override "255" . Accordingly , "num_usec" may not override "64" . 
       { TH0 = ~(1+4*(num_usec-1))  ; // timers<-PCLK=CCLK:2=7.373Mhz:2-> 271ns  
         TF0 = 0 ;                    // clear overflow flag 
         TR0 = 1 ;                    // start T0 
         while(!TF0)  ;               // wait overflow 
                                     } 
//............................................................................
    void dly5ms(void)                 // 5 miliseconds delay 
  { unsigned char j = 100      ;      // 100 * 50usec = 5 msec 
    while(--j) { dly_usec(50)  ; }  
                                   }  
//............................................................................
    void dly250ms(void)               // 250 miliseconds delay 
  { unsigned char k = 50       ;      //  50 * 5 msec = 250 msec 
    while(--k) { dly5ms()      ; }    // usefull for messages' display
                                   }  
//.............................................................................
    void dly1s(void)                  // 1 second delay  
  { dly250ms() ; dly250ms()    ;      // 4 * 250 ms = 1 second 
    dly250ms() ; dly250ms()    ;   }  // usefull for messages' display
//.............................................................................
       void tx_com1(unsigned char com1_buf)  // sends on UART1 line com1_buf  
       {                              //  TI1 = set in S1CON init 
//       while(!(S1CON&0x02))  ;      //  wait for TI_1 = 1 
//       S1CON &= 0xfd         ;      //  clear TI_1 
         while(!(S1CONX&0x02)) ; 
		 S1CONX &=0xfd         ;   
         S1BUF = com1_buf      ;      //  write data in serial data buffer                 
                                   }  
//*****************************************************************************          